@echo off& color 57& mode con: cols=20 lines=10& title Coelho Move& chcp 65001  >nul& setlocal

timeout /t 2 /nobreak > NUL
mode con: cols=2 lines=1& title Coelho Move

timeout /t 2 /nobreak > NUL
cls
echo. 
echo ===========================
echo. /// 🐰 COELHO MOVE 🐰 ///
echo ===========================
echo.
type "%~dp0info.txt"
echo.
timeout /t 5 /nobreak > NUL
echo. Aperte ESC para interromper
echo.
echo.Iniciado %date:~6,4%-%date:~3,2%-%date:~0,2% %time:~0,2%:%time:~3,5%
setlocal EnableDelayedExpansion

set "caminho=%CD%"
rem Define os caminhos completos
set "AHK=%caminho%\AutoHotkey64.exe"
set "SCRIPT=%caminho%\coelho_move.ahk"

"%AHK%" "%SCRIPT%"