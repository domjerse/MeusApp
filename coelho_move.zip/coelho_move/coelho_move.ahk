#Requires AutoHotkey v2.0

; ===== CONFIG =====
largura := 230
altura := 190
inicioPrograma := A_TickCount
alertaTocado := false

;Hotkey "Esc", (*) => ExitApp()

; ===== GUI =====
app := Gui("+AlwaysOnTop -Caption +ToolWindow")
app.BackColor := "Black"
app.SetFont("s11 cWhite", "Segoe UI")

WinSetTransparent(220, app)

; ===== HEADER =====
header := app.AddText("x0 y0 w" largura " h35 Background202020")

; área de arrastar (não cobre botões)
dragArea := app.AddText("x0 y0 w" largura-90 " h35 BackgroundTrans")
dragArea.OnEvent("Click", Arrastar)

; ===== BOTÕES =====
btnLogon := app.AddText("x10 y5 w20 Center cWhite BackgroundTrans", "🐰")
btnLogon.OnEvent("Click", AbrirJanela)

btnHelp := app.AddText("x" largura-75 " y5 w20 Center cYellow BackgroundTrans", "❓")
btnHelp.OnEvent("Click", MostrarAjuda)

btnMin := app.AddText("x" largura-50 " y5 w20 Center cWhite BackgroundTrans", "➖")
btnMin.OnEvent("Click", (*) => WinMinimize(app))

btnFechar := app.AddText("x" largura-25 " y5 w20 Center cRed BackgroundTrans", "❌")
btnFechar.OnEvent("Click", (*) => ExitApp())

; ===== TEXTOS =====
txtIdle   := app.AddText("x10 y50 w200", "🕒 Inativo: 00:00")
txtExec   := app.AddText("x10 y75 w200", "⏱ Execução: 00:00")
txtAgenda := app.AddText("x10 y100 w200", "📅 Agendado: --:--")
txtStatus := app.AddText("x10 y125 w200", "📒 Atividade: Inação")

txtIdle.OnEvent("Click", Arrastar)
txtExec.OnEvent("Click", Arrastar)
txtAgenda.OnEvent("Click", EditarHorario)
txtStatus.OnEvent("Click", DefinirExecucao)

; ===== FOOTER =====
footer := app.AddText("x0 y" altura-25 " w" largura " h20 Background202020 cLime Left", "● Online")

app.Show("w" largura " h" altura " x10 y10 NoActivate")

SetTimer(Atualizar, 1000)

; ===== VAR EXECUÇÃO =====
caminhoExec := A_ScriptDir "\teste.bat"

; =========================
; ===== FUNÇÕES ===========
; =========================

Atualizar() {
    global txtIdle, txtExec, txtAgenda, inicioPrograma, alertaTocado

    tempoIdle := A_TimeIdle // 1000
    txtIdle.Value := "🕒 Inativo: " Format("{:02}:{:02}", Floor(tempoIdle/60), Mod(tempoIdle,60))

    tempoExec := (A_TickCount - inicioPrograma) // 1000
    txtExec.Value := "⏱ Execução: " Format("{:02}:{:02}", Floor(tempoExec/60), Mod(tempoExec,60))

    if RegExMatch(txtAgenda.Value, "(\d{2}:\d{2})", &m) {
        if (m[1] = FormatTime(, "HH:mm") && !alertaTocado) {
            alertaTocado := true
            DispararAlerta()
        }
    } else {
        alertaTocado := false
    }

    AntiIdle()
}

DispararAlerta() {
    global txtAgenda, caminhoExec

    SoundBeep(1500, 300)
    SoundBeep(1500, 300)

    if FileExist(caminhoExec) {
        Run(caminhoExec)
    } else {
        MsgBox("⚠ Arquivo não encontrado:`n" caminhoExec)
    }

    txtAgenda.Value := "📅 Agendado: --:--"
}

; ===== DEFINIR EXECUÇÃO =====
DefinirExecucao(*) {
    global caminhoExec, txtStatus

    default := caminhoExec

    r := InputBox(
        "Digite o caminho completo do arquivo (.bat, .exe, etc):",
        "Executar arquivo",
        , default
    )

    if (r.Result = "OK") {
        caminhoExec := r.Value

        if FileExist(caminhoExec) {
            txtStatus.Value := "📒 Atividade: OK"
        } else {
            txtStatus.Value := "📒 Atividade: Arquivo não encontrado"
            MsgBox("⚠ Caminho inválido!")
        }
    }
}

EditarHorario(*) {
    global txtAgenda

    r := InputBox("Digite HH:mm", "Agendar horário")

    if (r.Result = "OK" && RegExMatch(r.Value, "^(?:[01]\d|2[0-3]):[0-5]\d$")) {
        txtAgenda.Value := "📅 Agendado: " r.Value
    } else if (r.Result = "Ação") {
        MsgBox("Formato inválido! Use HH:mm")
    }
}

MostrarAjuda(*) {
    MsgBox(
        "Sis Coelho Move v2.3`n"
      . "por: Dom Jerser`n"
      . "contato: gerson1.jr@gmail.com",
        "Sobre"
    )
}

Arrastar(*) {
    PostMessage(0xA1, 2)
}

AntiIdle() {
    MouseGetPos &x, &y
    MouseMove(x+1, y, 0)
    MouseMove(x, y, 0)
}

; ===== SEGUNDA JANELA =====
AbrirJanela(*) {

    largura2 := 250
    altura2 := 120

    painel := Gui("+AlwaysOnTop -Caption +ToolWindow")
    painel.BackColor := "1E1E1E"
    painel.SetFont("s10 cWhite", "Segoe UI")

    header2 := painel.AddText("x0 y0 w" largura2 " h25 Background303030")
    header2.OnEvent("Click", Arrastar)

    painel.AddText("x0 y5 w" largura2 " Center", "🐰 Painel Coelho")
    painel.AddText("x0 y40 w" largura2 " Center", "Sistema em execução")
    painel.AddText("x0 y65 w" largura2 " Center", "Versão 2.3")

    btnClose := painel.AddText("x" largura2-25 " y5 w20 Center cRed BackgroundTrans", "❌")
    btnClose.OnEvent("Click", (*) => painel.Destroy())

    painel.Show("w" largura2 " h" altura2 " Center")
}