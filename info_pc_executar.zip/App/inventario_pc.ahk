#Requires AutoHotkey v2.0
;Nota importante win+i win+r dxdiag

; =========================
; Solicitar ID
; =========================
idInput := InputBox("Digite sua identificação:", "Acesso ID")
if (idInput.Result != "OK" || idInput.Value = "") {
    MsgBox "Operação cancelada."
    ExitApp
}
userID := idInput.Value

; =========================
; Nome do arquivo
; =========================
timestamp := FormatTime(, "yyyy_MM_dd_HHmmss")
output := A_ScriptDir "\..\info_pc_" timestamp ".txt"

; =========================
; Função de escrita
; =========================
WriteLine(text) {
    global output
    FileAppend text "`n", output
}

; =========================
WriteLine("=================================")
WriteLine("INFORMACOES DO PC")
WriteLine("=================================")
WriteLine("")

; ID informado
WriteLine("ID: " userID)

; Usuario
WriteLine("Nome do Usuário: " A_UserName)
WriteLine("Nome do Dispositivo: " A_ComputerName)

; WMI
wmi := ComObjGet("winmgmts:\\.\root\cimv2")

; CPU
for cpu in wmi.ExecQuery("Select Name, MaxClockSpeed from Win32_Processor") {
    WriteLine("Processador: " cpu.Name " (" cpu.MaxClockSpeed " MHz)")
    break
}

; RAM
for os in wmi.ExecQuery("Select TotalVisibleMemorySize, FreePhysicalMemory from Win32_OperatingSystem") {
    total := Round(os.TotalVisibleMemorySize / 1024 / 1024, 1)
    free := Round(os.FreePhysicalMemory / 1024 / 1024, 1)
    used := Round(total - free, 1)

    WriteLine("RAM instalada: " total " GB (utilizável: " used " GB)")
    break
}

; Sistema
for os in wmi.ExecQuery("Select OSArchitecture from Win32_OperatingSystem") {
    WriteLine("Tipo de sistema: " os.OSArchitecture)
    break
}

; Disco
for disk in wmi.ExecQuery("Select FreeSpace, Size from Win32_LogicalDisk where DeviceID='C:'") {
    total := Round(disk.Size / 1024 / 1024 / 1024, 1)
    free := Round(disk.FreeSpace / 1024 / 1024 / 1024, 1)
    used := Round(total - free, 1)

    WriteLine("Espaço Livre: " free " GB")
    WriteLine("Espaço Usado: " used " GB")
    WriteLine("Capacidade de Armazenamento: " total " GB")
    break
}

; GPU
for gpu in wmi.ExecQuery("Select Name, AdapterRAM from Win32_VideoController") {
    vram := Round(gpu.AdapterRAM / 1024 / 1024)
    WriteLine("Placa de Vídeo: " vram " MB")
    break
}

; Fabricante + Modelo
for cs in wmi.ExecQuery("Select Manufacturer, Model from Win32_ComputerSystem") {
    WriteLine("Fabricante: " cs.Manufacturer)
    WriteLine("Modelo: " cs.Model)
    break
}

; Serial
for bios in wmi.ExecQuery("Select SerialNumber from Win32_BIOS") {
    WriteLine("Serial: " bios.SerialNumber)
    break
}

; BIOS
for bios in wmi.ExecQuery("Select Manufacturer from Win32_BIOS") {
    WriteLine("BIOS: " bios.Manufacturer)
    break
}


; =========================
; Tipo de disco (SSD/HDD/NVMe)
; =========================
try {
    storage := ComObjGet("winmgmts:\\.\root\Microsoft\Windows\Storage")

    for disk in storage.ExecQuery("Select FriendlyName, MediaType from MSFT_PhysicalDisk") {

        tipo := "Desconhecido"

        if (disk.MediaType = 4)
            tipo := "SSD"
        else if (disk.MediaType = 3)
            tipo := "HDD"

        ; Detectar NVMe pelo nome
        if InStr(disk.FriendlyName, "NVMe")
            tipo := "SSD (NVMe)"

        WriteLine("Disco: " disk.FriendlyName)
        WriteLine("Tipo: " tipo)
        WriteLine("")
    }

} catch {
    WriteLine("Tipo de disco: Não foi possível determinar")
}

MsgBox "Coleta concluída! Arquivo salvo como " output