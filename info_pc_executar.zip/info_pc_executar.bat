@echo off& color 57& mode con: cols=10 lines=5& title Info PC FAT/FIN& chcp 65001  >nul& setlocal
setlocal EnableDelayedExpansion
timeout /t 2 /nobreak > NUL
;mode con: cols=2 lines=1& title Info PC Carregando...

timeout /t 2 /nobreak > NUL
cls
echo. 
echo. /// ✅🤖 Info Sistemas - FatFin 🤝 ✅ ///
echo. Informações de Hardware ⚙️ e software 💻 corporativo
echo.
echo. YDUQS - Serviços de Faturamento e Financiamentos
echo.
echo. Estácio Super Campus Maracanã
echo.
echo. Admin Gerson Gomes - Sistema Info PC v1.0, RJ - 2026-05-05
echo.

echo. Iniciado %date:~6,4%-%date:~3,2%-%date:~0,2% %time:~0,2%:%time:~3,5%
timeout /t 5 

set "caminho=%CD%"
rem Define os caminhos completos
set "AHK=%caminho%\App\AutoHotkey64.exe"
set "SCRIPT=%caminho%\App\inventario_pc.ahk"

"%AHK%" "%SCRIPT%"

