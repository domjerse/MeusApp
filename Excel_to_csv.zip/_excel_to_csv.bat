@echo off& color 57& mode con: cols=20 lines=10& title Etel Dom Jerse v1.2& chcp 65001  >nul& setlocal
setlocal EnableDelayedExpansion

timeout /t 1 /nobreak > NUL

echo. Iniciado %date:~6,4%-%date:~3,2%-%date:~0,2% %time:~0,2%:%time:~3,5%

set "stDir=%~dp0"

set "AHK=%stDir%\sis\AutoHotkey64.exe"
set "SCRIPT=%stDir%\sis\csvsalva.ahk"

"%AHK%" "%SCRIPT%"

rem MOVE Arquivo.csv..

rem DEL "Arquivo*.xlsx"