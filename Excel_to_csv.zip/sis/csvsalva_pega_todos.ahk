#Requires AutoHotkey v2.0

pastaEntrada := A_ScriptDir "\.." ;Um nível acima
pastaSaida   := A_ScriptDir "\.." ;Um nível acima

if !DirExist(pastaSaida)
    DirCreate(pastaSaida)

excel := ComObject("Excel.Application")
excel.Visible := false
excel.DisplayAlerts := false

ToolTip "Iniciando conversão..."

; =============================
; LOOP DOS ARQUIVOS
; =============================
Loop Files, pastaEntrada "\Arquivo*.xlsx" {

    arquivoExcel := A_LoopFileFullPath
    nomeOriginal := A_LoopFileName

    ; troca extensão para CSV
    nomeCSV := RegExReplace(nomeOriginal, "\.xlsx$", ".csv")

    ToolTip "Processando:`n" nomeOriginal

    wb := excel.Workbooks.Open(arquivoExcel)

    ; =============================
    ; LOOP DAS ABAS
    ; =============================
    for sheet in wb.Sheets {

        caminhoCSV := pastaSaida "\" nomeCSV

        ToolTip "Arquivo: " nomeCSV "`nAba: " sheet.Name

        sheet.SaveAs(caminhoCSV, 6) ; CSV
        Sleep 300
    }

    wb.Close(false)
}

ToolTip
excel.Quit()

MsgBox "Conversão concluída com sucesso!"