#Requires AutoHotkey v2.0

pastaEntrada := A_ScriptDir "\.." ;Um nível acima
pastaSaida   := A_ScriptDir "\.." ;Um nível acima

if !DirExist(pastaSaida)
    DirCreate(pastaSaida)

; =============================
; PADRÃO DO ARQUIVO → NOME DE SAÍDA
; =============================
arquivos := Map(
    "Arquivo*.xlsx", "tb_arquivo",
    "Arquivo2*.xlsx", "tb_arquivo2"
)

excel := ComObject("Excel.Application")
excel.Visible := false
excel.DisplayAlerts := false

ToolTip "Iniciando conversão..."

; =============================
; LOOP DOS PADRÕES
; =============================
for padrao, nomeSaida in arquivos {

    Loop Files, pastaEntrada "\" padrao {
        arquivoExcel := A_LoopFileFullPath

        ToolTip "Processando:`n" padrao

        wb := excel.Workbooks.Open(arquivoExcel)

        ; =============================
        ; LOOP DAS ABAS
        ; =============================
        for sheet in wb.Sheets {

            ToolTip "Arquivo: " nomeSaida "`nAba: " sheet.Name

            caminhoCSV :=
                pastaSaida "\" nomeSaida ".csv" 
			      ;nomeSaida "_" sheet.Name ".csv" ;Se quiser incluir o nome da aba

            sheet.SaveAs(caminhoCSV, 6) ; CSV separado por vírgula
            Sleep 300
        }

        wb.Close(false)
    }
}

ToolTip
excel.Quit()

MsgBox "Conversão concluída com sucesso!"